package com.example.gsmnotes;

import com.example.gsmnotes.entities.Device;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;

public class DeviceService {

    public List<Device> getAllDevices() {
        ArrayList<Device> a = new ArrayList<>();
        Device d = new Device();
        d.setName("Hello, friends");
        a.add(d);
        return a;
    }

}
