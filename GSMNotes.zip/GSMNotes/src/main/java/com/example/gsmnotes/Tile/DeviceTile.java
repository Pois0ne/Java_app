

package com.example.gsmnotes.Tile;

import com.example.gsmnotes.entities.Device;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;

import java.io.IOException;

public class DeviceTile extends HBox {

    @FXML
    Label TTitle;

    @FXML
    ImageView TImage;

    @FXML
    TextArea TText;

    // ... copy from G. V.

    public DeviceTile() {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Tile.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public void setDevice(Device d) {
        this.TTitle.setText(d.getName());
    }


    }

