open module com.onegin.language {
    requires javafx.controls;
    requires javafx.fxml;
    requires spring.boot.autoconfigure;
    requires spring.boot;
    requires spring.core;
    requires java.persistence;
    requires spring.data.commons;
    requires spring.context;
    requires spring.beans;
    requires java.sql;
    requires spring.data.jpa;
    requires org.hibernate.orm.core;
    requires spring.tx;
}